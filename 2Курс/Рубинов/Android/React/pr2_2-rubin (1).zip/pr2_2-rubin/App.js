import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
       Пять фильмов с Умой Турман
      </Text>
      <Card>
      <Text style={styles.center}>
      Убить Билла 1 и 2 (2003 и 2004)
      </Text>
        <Card style={{backgroundColor: '#808080'}}>
        <Text style={{ margin:10}}>
        Вероятно, что многие при упоминании имени актрисы в первую очередь вспоминают этот фильм. Квентин Тарантино снова позвонил Уме Турман спустя несколько лет. На этот раз предлагая сыграть в его фильме главную роль, с которой актриса справилась великолепно. Персонаж, пытающийся отомстить свои обидчикам, получился настолько ярким, что Ума снова появилась на плакатах, афишах и обложках всевозможных журналов.
        </Text>
        </Card>
      </Card>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  center: {
    margin: 24,
    fontSize: 18,
    textAlign: 'center',
    //flex: 1,
  },
});
