import * as React from 'react';
import { Text, View,Image, StyleSheet } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
        Журнал Bright
      </Text>
      <Card>
        <Text style={styles.blue}>
          Новости
        </Text>
        <Image source = {{uri: 'https://storage.theoryandpractice.ru/tnp/uploads/image_unit/000/159/195/image/base_23864799f8.jpg',}} 
        style={{ margin: 10, width: 200, height: 200 }}
        />
        <Text style ={styles.Bigtxt}>
        Как музыка может улучшить качество нашей жизни?
        </Text>
        <Text style ={styles.txt}>
          Музыка во все времена и в разных культурах играла очень важную роль. Наши предки погружались в нее и в горе, и в радости.
        </Text>
      </Card>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  blue: {
    margin: 10,
    color: 'blue',},
  txt: {
    margin: 10,
    },
  Bigtxt: {
    fontWeight: 'bold',
    margin: 10,
    }
});

